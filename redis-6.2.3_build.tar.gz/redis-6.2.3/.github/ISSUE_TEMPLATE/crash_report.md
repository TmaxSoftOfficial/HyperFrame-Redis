---
name: Crash report
about: Submit a crash report
title: '[CRASH]'
labels: ''
assignees: ''

---

**Crash report**

Paste the complete crash log between the quotes below. Please include a few lines from the log preceding the crash report to provide some context.

```
```

**Aditional information**

1. OS distribution and version
2. Steps to reproduce (if any)
